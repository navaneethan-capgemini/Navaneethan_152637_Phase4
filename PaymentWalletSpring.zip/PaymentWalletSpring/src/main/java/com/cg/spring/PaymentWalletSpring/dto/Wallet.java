package com.cg.spring.PaymentWalletSpring.dto;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class Wallet implements Serializable {

	
	private Double balance;

	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wallet(Double balance) {
		super();
		this.balance = balance;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}
	
	
}
